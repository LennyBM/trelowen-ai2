
(function() {
    'use strict';
    
    // Configuration
    const TRELOWEN_CONFIG = {
        apiUrl: 'https://trelowen-ai.onrender.com/api/chat',
        widgetId: 'trelowen-chat-widget',
        position: 'bottom-right',
        theme: 'light'
    };
    
    // Prevent multiple initializations
    if (window.TrelowenWidget) {
        console.warn('Trelowen Widget already initialized');
        return;
    }
    
    class TrelowenChatWidget {
        constructor() {
            this.isOpen = false;
            this.messages = [];
            this.init();
        }
        
        init() {
            this.createStyles();
            this.createWidget();
            this.attachEventListeners();
        }
        
        createStyles() {
            const style = document.createElement('style');
            style.textContent = `
                #trelowen-chat-widget {
                    position: fixed;
                    bottom: 20px;
                    right: 20px;
                    z-index: 10000;
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                }
                
                .trelowen-chat-button {
                    width: 60px;
                    height: 60px;
                    border-radius: 50%;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    border: none;
                    cursor: pointer;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    transition: all 0.3s ease;
                }
                
                .trelowen-chat-button:hover {
                    transform: scale(1.1);
                    box-shadow: 0 6px 20px rgba(0,0,0,0.2);
                }
                
                .trelowen-chat-button svg {
                    width: 24px;
                    height: 24px;
                    fill: white;
                }
                
                .trelowen-chat-container {
                    position: absolute;
                    bottom: 80px;
                    right: 0;
                    width: 350px;
                    height: 500px;
                    background: white;
                    border-radius: 12px;
                    box-shadow: 0 8px 32px rgba(0,0,0,0.12);
                    display: none;
                    flex-direction: column;
                    overflow: hidden;
                    border: 1px solid #e1e5e9;
                }
                
                .trelowen-chat-container.open {
                    display: flex;
                    animation: slideUp 0.3s ease-out;
                }
                
                @keyframes slideUp {
                    from {
                        opacity: 0;
                        transform: translateY(20px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
                
                .trelowen-chat-header {
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    padding: 16px;
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                }
                
                .trelowen-chat-title {
                    font-weight: 600;
                    font-size: 16px;
                }
                
                .trelowen-chat-close {
                    background: none;
                    border: none;
                    color: white;
                    cursor: pointer;
                    padding: 4px;
                    border-radius: 4px;
                    transition: background-color 0.2s;
                }
                
                .trelowen-chat-close:hover {
                    background-color: rgba(255,255,255,0.1);
                }
                
                .trelowen-chat-messages {
                    flex: 1;
                    padding: 16px;
                    overflow-y: auto;
                    background: #f8f9fa;
                }
                
                .trelowen-message {
                    margin-bottom: 12px;
                    display: flex;
                    flex-direction: column;
                }
                
                .trelowen-message.user {
                    align-items: flex-end;
                }
                
                .trelowen-message.bot {
                    align-items: flex-start;
                }
                
                .trelowen-message-bubble {
                    max-width: 80%;
                    padding: 12px 16px;
                    border-radius: 18px;
                    font-size: 14px;
                    line-height: 1.4;
                    word-wrap: break-word;
                }
                
                .trelowen-message.user .trelowen-message-bubble {
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                }
                
                .trelowen-message.bot .trelowen-message-bubble {
                    background: white;
                    color: #333;
                    border: 1px solid #e1e5e9;
                }
                
                .trelowen-chat-input-container {
                    padding: 16px;
                    border-top: 1px solid #e1e5e9;
                    background: white;
                }
                
                .trelowen-chat-input-form {
                    display: flex;
                    gap: 8px;
                }
                
                .trelowen-chat-input {
                    flex: 1;
                    padding: 12px;
                    border: 1px solid #e1e5e9;
                    border-radius: 24px;
                    outline: none;
                    font-size: 14px;
                    resize: none;
                    max-height: 100px;
                }
                
                .trelowen-chat-input:focus {
                    border-color: #667eea;
                }
                
                .trelowen-chat-send {
                    width: 40px;
                    height: 40px;
                    border-radius: 50%;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    border: none;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    transition: transform 0.2s;
                }
                
                .trelowen-chat-send:hover {
                    transform: scale(1.05);
                }
                
                .trelowen-chat-send:disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                    transform: none;
                }
                
                .trelowen-chat-send svg {
                    width: 16px;
                    height: 16px;
                    fill: white;
                }
                
                .trelowen-typing-indicator {
                    display: flex;
                    align-items: center;
                    gap: 4px;
                    padding: 12px 16px;
                    background: white;
                    border-radius: 18px;
                    border: 1px solid #e1e5e9;
                    max-width: 80%;
                }
                
                .trelowen-typing-dot {
                    width: 6px;
                    height: 6px;
                    border-radius: 50%;
                    background: #999;
                    animation: typing 1.4s infinite ease-in-out;
                }
                
                .trelowen-typing-dot:nth-child(1) { animation-delay: -0.32s; }
                .trelowen-typing-dot:nth-child(2) { animation-delay: -0.16s; }
                
                @keyframes typing {
                    0%, 80%, 100% {
                        transform: scale(0.8);
                        opacity: 0.5;
                    }
                    40% {
                        transform: scale(1);
                        opacity: 1;
                    }
                }
                
                @media (max-width: 480px) {
                    #trelowen-chat-widget {
                        bottom: 10px;
                        right: 10px;
                    }
                    
                    .trelowen-chat-container {
                        width: calc(100vw - 20px);
                        height: calc(100vh - 100px);
                        bottom: 70px;
                        right: -10px;
                    }
                }
            `;
            document.head.appendChild(style);
        }
        
        createWidget() {
            const widget = document.createElement('div');
            widget.id = TRELOWEN_CONFIG.widgetId;
            widget.innerHTML = `
                <button class="trelowen-chat-button" id="trelowen-chat-toggle">
                    <svg viewBox="0 0 24 24">
                        <path d="M20 2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h4l4 4 4-4h4c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z"/>
                    </svg>
                </button>
                
                <div class="trelowen-chat-container" id="trelowen-chat-container">
                    <div class="trelowen-chat-header">
                        <div class="trelowen-chat-title">Trelowen AI Assistant</div>
                        <button class="trelowen-chat-close" id="trelowen-chat-close">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
                            </svg>
                        </button>
                    </div>
                    
                    <div class="trelowen-chat-messages" id="trelowen-chat-messages">
                        <div class="trelowen-message bot">
                            <div class="trelowen-message-bubble">
                                Hello! I'm the Trelowen AI Assistant. How can I help you today?
                            </div>
                        </div>
                    </div>
                    
                    <div class="trelowen-chat-input-container">
                        <form class="trelowen-chat-input-form" id="trelowen-chat-form">
                            <textarea 
                                class="trelowen-chat-input" 
                                id="trelowen-chat-input" 
                                placeholder="Type your message..."
                                rows="1"
                            ></textarea>
                            <button type="submit" class="trelowen-chat-send" id="trelowen-chat-send">
                                <svg viewBox="0 0 24 24">
                                    <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
                                </svg>
                            </button>
                        </form>
                    </div>
                </div>
            `;
            
            document.body.appendChild(widget);
        }
        
        attachEventListeners() {
            const toggleBtn = document.getElementById('trelowen-chat-toggle');
            const closeBtn = document.getElementById('trelowen-chat-close');
            const form = document.getElementById('trelowen-chat-form');
            const input = document.getElementById('trelowen-chat-input');
            
            toggleBtn.addEventListener('click', () => this.toggleChat());
            closeBtn.addEventListener('click', () => this.closeChat());
            form.addEventListener('submit', (e) => this.handleSubmit(e));
            
            // Auto-resize textarea
            input.addEventListener('input', () => {
                input.style.height = 'auto';
                input.style.height = Math.min(input.scrollHeight, 100) + 'px';
            });
            
            // Enter to send (Shift+Enter for new line)
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    form.dispatchEvent(new Event('submit'));
                }
            });
        }
        
        toggleChat() {
            const container = document.getElementById('trelowen-chat-container');
            this.isOpen = !this.isOpen;
            
            if (this.isOpen) {
                container.classList.add('open');
                document.getElementById('trelowen-chat-input').focus();
            } else {
                container.classList.remove('open');
            }
        }
        
        closeChat() {
            const container = document.getElementById('trelowen-chat-container');
            container.classList.remove('open');
            this.isOpen = false;
        }
        
        async handleSubmit(e) {
            e.preventDefault();
            
            const input = document.getElementById('trelowen-chat-input');
            const sendBtn = document.getElementById('trelowen-chat-send');
            const message = input.value.trim();
            
            if (!message) return;
            
            // Add user message
            this.addMessage(message, 'user');
            
            // Clear input and disable send button
            input.value = '';
            input.style.height = 'auto';
            sendBtn.disabled = true;
            
            // Show typing indicator
            this.showTypingIndicator();
            
            try {
                // Send message to API
                const response = await fetch(TRELOWEN_CONFIG.apiUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ message })
                });
                
                const data = await response.json();
                
                // Remove typing indicator
                this.hideTypingIndicator();
                
                // Add bot response
                if (data.response) {
                    this.addMessage(data.response, 'bot');
                } else if (data.message) {
                    this.addMessage(data.message, 'bot');
                } else {
                    this.addMessage('I apologize, but I encountered an issue. Please try again or contact our sales team directly at 01288 361940.', 'bot');
                }
                
            } catch (error) {
                console.error('Chat error:', error);
                this.hideTypingIndicator();
                this.addMessage('I apologize, but I encountered a connection issue. Please try again or contact our sales team directly at 01288 361940.', 'bot');
            } finally {
                sendBtn.disabled = false;
            }
        }
        
        addMessage(text, sender) {
            const messagesContainer = document.getElementById('trelowen-chat-messages');
            const messageDiv = document.createElement('div');
            messageDiv.className = `trelowen-message ${sender}`;
            messageDiv.innerHTML = `
                <div class="trelowen-message-bubble">
                    ${this.escapeHtml(text)}
                </div>
            `;
            
            messagesContainer.appendChild(messageDiv);
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
            
            this.messages.push({ text, sender, timestamp: new Date() });
        }
        
        showTypingIndicator() {
            const messagesContainer = document.getElementById('trelowen-chat-messages');
            const typingDiv = document.createElement('div');
            typingDiv.className = 'trelowen-message bot';
            typingDiv.id = 'trelowen-typing';
            typingDiv.innerHTML = `
                <div class="trelowen-typing-indicator">
                    <div class="trelowen-typing-dot"></div>
                    <div class="trelowen-typing-dot"></div>
                    <div class="trelowen-typing-dot"></div>
                </div>
            `;
            
            messagesContainer.appendChild(typingDiv);
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
        
        hideTypingIndicator() {
            const typingIndicator = document.getElementById('trelowen-typing');
            if (typingIndicator) {
                typingIndicator.remove();
            }
        }
        
        escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    }
    
    // Initialize widget when DOM is ready
    function initWidget() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                window.TrelowenWidget = new TrelowenChatWidget();
            });
        } else {
            window.TrelowenWidget = new TrelowenChatWidget();
        }
    }
    
    initWidget();
})();
