
# Trelowen AI Chat Widget

This directory contains the embeddable chat widget for the Trelowen AI Assistant.

## Files

- `widget.js` - Main widget script with embedded styles
- `widget.css` - Optional standalone CSS file (styles are included in widget.js)
- `README.md` - This documentation file

## Usage

To embed the chat widget on any website, add this script tag to your HTML:

```html
<script src="https://your-domain.com/widget/widget.js" defer></script>
```

## Features

- Responsive design that works on desktop and mobile
- Modern, clean UI with smooth animations
- Automatic API endpoint detection
- Typing indicators
- Message history within session
- Keyboard shortcuts (Enter to send, Shift+Enter for new line)
- Auto-resizing input field
- Error handling with fallback messages

## Customization

The widget automatically adapts to your domain and uses the `/api/chat` endpoint. No additional configuration is required.

## Browser Support

- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## Security

The widget uses HTTPS when available and includes XSS protection through HTML escaping.
