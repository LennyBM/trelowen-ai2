
import { generateChatResponse } from '../utils/openai';
import { logger } from '../utils/logger';

interface LeadInsights {
  budgetRange?: string;
  interestType?: string;
  customerStage?: string;
  urgency?: string;
  contactInfo?: {
    hasEmail?: boolean;
    hasPhone?: boolean;
    hasName?: boolean;
  };
  qualificationScore?: number;
}

class LeadIntelligenceService {
  async analyzeConversation(message: string, history: any[] = []): Promise<LeadInsights> {
    try {
      // Simple keyword-based analysis as fallback
      const fullConversation = history.map(msg => msg.content).join('\n') + '\n' + message;
      const conversationLower = fullConversation.toLowerCase();
      
      // Try OpenAI analysis first, fall back to keyword analysis
      try {
        const analysisPrompt = `Analyze this conversation with a potential Trelowen Lodges customer and extract lead intelligence:

Conversation:
${fullConversation}

Extract the following information if mentioned or implied:

1. Budget Range (choose one):
   - Under £300k
   - £300k-£400k  
   - £400k-£500k
   - £500k-£750k
   - £750k-£1M
   - Over £1M
   - Unknown

2. Interest Type (choose one):
   - Investment focused
   - Personal use focused
   - Mixed investment/personal
   - Just browsing
   - Unknown

3. Customer Stage (choose one):
   - Initial inquiry
   - Researching options
   - Comparing properties
   - Ready to view
   - Ready to purchase
   - Unknown

4. Urgency Level (choose one):
   - High (wants to act soon)
   - Medium (considering timeframe)
   - Low (early stage research)
   - Unknown

5. Contact Information Available:
   - Has provided name: true/false
   - Has provided email: true/false
   - Has provided phone: true/false

Respond in JSON format only:
{
  "budgetRange": "...",
  "interestType": "...",
  "customerStage": "...",
  "urgency": "...",
  "contactInfo": {
    "hasName": true/false,
    "hasEmail": true/false,
    "hasPhone": true/false
  }
}`;

        const response = await generateChatResponse([
          { role: 'user', content: analysisPrompt }
        ], 'You are a lead analysis expert. Respond only with valid JSON.');

        try {
          const insights = JSON.parse(response);
          return insights;
        } catch (parseError) {
          logger.warn('Failed to parse lead analysis response:', response);
          throw parseError;
        }
      } catch (openaiError) {
        logger.warn('OpenAI unavailable for lead analysis, using keyword-based fallback');
        
        // Fallback keyword-based analysis
        const insights: LeadInsights = {};
        
        // Budget analysis
        if (conversationLower.includes('million') || conversationLower.includes('1m') || conversationLower.includes('£1')) {
          insights.budgetRange = 'Over £1M';
        } else if (conversationLower.includes('750') || conversationLower.includes('800') || conversationLower.includes('900')) {
          insights.budgetRange = '£750k-£1M';
        } else if (conversationLower.includes('500') || conversationLower.includes('600') || conversationLower.includes('700')) {
          insights.budgetRange = '£500k-£750k';
        } else if (conversationLower.includes('400') || conversationLower.includes('450') || conversationLower.includes('475')) {
          insights.budgetRange = '£400k-£500k';
        } else if (conversationLower.includes('300') || conversationLower.includes('350') || conversationLower.includes('425')) {
          insights.budgetRange = '£300k-£400k';
        }
        
        // Interest type analysis
        if (conversationLower.includes('investment') || conversationLower.includes('rental') || conversationLower.includes('yield') || conversationLower.includes('roi')) {
          insights.interestType = 'Investment';
        } else if (conversationLower.includes('holiday') || conversationLower.includes('personal') || conversationLower.includes('family')) {
          insights.interestType = 'Personal Use';
        } else if (conversationLower.includes('both') || conversationLower.includes('mix')) {
          insights.interestType = 'Mixed Use';
        }
        
        // Customer stage analysis
        if (conversationLower.includes('viewing') || conversationLower.includes('visit') || conversationLower.includes('book') || conversationLower.includes('ready')) {
          insights.customerStage = 'Ready to View';
        } else if (conversationLower.includes('interested') || conversationLower.includes('considering') || conversationLower.includes('thinking')) {
          insights.customerStage = 'Interested';
        } else if (conversationLower.includes('research') || conversationLower.includes('looking') || conversationLower.includes('information')) {
          insights.customerStage = 'Researching';
        }
        
        // Urgency analysis
        if (conversationLower.includes('soon') || conversationLower.includes('quickly') || conversationLower.includes('urgent') || conversationLower.includes('asap')) {
          insights.urgency = 'High';
        } else if (conversationLower.includes('month') || conversationLower.includes('weeks') || conversationLower.includes('considering')) {
          insights.urgency = 'Medium';
        } else {
          insights.urgency = 'Low';
        }
        
        return insights;
      }

    } catch (error) {
      logger.error('Error analyzing conversation:', error);
      return {};
    }
  }

  calculateQualificationScore(insights: LeadInsights): number {
    let score = 0;

    // Budget range scoring
    switch (insights.budgetRange) {
      case 'Over £1M':
      case '£750k-£1M':
      case '£500k-£750k':
        score += 30;
        break;
      case '£400k-£500k':
        score += 25;
        break;
      case '£300k-£400k':
        score += 20;
        break;
      case 'Under £300k':
        score += 10;
        break;
    }

    // Interest type scoring
    switch (insights.interestType) {
      case 'Investment focused':
      case 'Mixed investment/personal':
        score += 25;
        break;
      case 'Personal use focused':
        score += 20;
        break;
      case 'Just browsing':
        score += 5;
        break;
    }

    // Customer stage scoring
    switch (insights.customerStage) {
      case 'Ready to purchase':
        score += 30;
        break;
      case 'Ready to view':
        score += 25;
        break;
      case 'Comparing properties':
        score += 20;
        break;
      case 'Researching options':
        score += 15;
        break;
      case 'Initial inquiry':
        score += 10;
        break;
    }

    // Urgency scoring
    switch (insights.urgency) {
      case 'High':
        score += 15;
        break;
      case 'Medium':
        score += 10;
        break;
      case 'Low':
        score += 5;
        break;
    }

    return Math.min(score, 100);
  }

  getRecommendations(insights: LeadInsights): string[] {
    const recommendations: string[] = [];

    if (insights.customerStage === 'Ready to view' || insights.customerStage === 'Ready to purchase') {
      recommendations.push('Priority lead - arrange VIP viewing immediately');
    }

    if (insights.urgency === 'High') {
      recommendations.push('High urgency - follow up within 24 hours');
    }

    if (insights.budgetRange && ['Over £1M', '£750k-£1M', '£500k-£750k'].includes(insights.budgetRange)) {
      recommendations.push('High-value prospect - assign senior sales consultant');
    }

    if (insights.interestType === 'Investment focused') {
      recommendations.push('Focus on ROI, yield figures, and investment benefits');
    }

    if (!insights.contactInfo?.hasEmail && !insights.contactInfo?.hasPhone) {
      recommendations.push('Capture contact information for follow-up');
    }

    return recommendations;
  }
}

export const leadIntelligenceService = new LeadIntelligenceService();
