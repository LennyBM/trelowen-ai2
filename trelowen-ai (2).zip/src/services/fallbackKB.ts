
import { logger } from '../utils/logger';

// Fallback knowledge base without embeddings for when OpenAI quota is exceeded
const TRELOWEN_KNOWLEDGE_BASE = {
  pricing: {
    content: `Current Lodge Prices (2024):
- 2-Bedroom Lodge: £425,000 (fully furnished & turnkey ready)
- 3-Bedroom Lodge: £450,000 (fully furnished & turnkey ready)
- 4-Bedroom Lodge: £475,000 (fully furnished & turnkey ready)

Payment Terms:
- Reservation Deposit: £5,000 to reserve lodge
- Payment Structure: Full payment due prior to completion
- Financing: No current in-house financing available

Annual Service Charges:
- With Sublet Service: £6,500 annually (includes full rental management)
- Without Sublet Service: £8,500 annually (owner manages rentals independently)`,
    keywords: ['price', 'cost', 'payment', 'deposit', 'financing', 'service charge', 'annual']
  },
  
  investment: {
    content: `Investment Benefits:
- Approximately 8% rental yield (discussed only in personal consultations)
- Strong ROI Potential with professional management
- Passive Income through comprehensive sublet service
- Capital Growth in sought-after Cornwall market
- Year-Round Usage: 12-month access for personal use
- Professional Management: Optional hands-off rental management`,
    keywords: ['investment', 'yield', 'roi', 'return', 'rental', 'income', 'profit']
  },
  
  features: {
    content: `Property Features:
- Fully Electric: No gas - completely eco-friendly setup
- Solar Powered: Integrated roof solar panels
- Green Roofs: Flowerbed roofs with rainwater collection
- High-Spec Interiors: Premium finishes throughout
- Fully Furnished & Turnkey Ready: Complete furniture, kitchen essentials, appliances
- Key Selling Point: "Just bring your suitcase – everything else is ready!"`,
    keywords: ['features', 'eco-friendly', 'solar', 'furnished', 'turnkey', 'electric', 'green']
  },
  
  location: {
    content: `Location Benefits:
- Address: Whalesborough Farm, Marhamchurch, Bude, EX23 0JD, North Cornwall
- Resort Features: The W Club Spa, Swimming Pool, The Weir Restaurant, Gym (all 1-minute walk)
- North Cornwall: Prestigious location in England's most desirable coastal regions
- Bude Proximity: Close to popular seaside town
- Access: ANPR gate system with 24/7 secure access
- Parking: Dedicated signposted car park spaces`,
    keywords: ['location', 'cornwall', 'bude', 'resort', 'spa', 'facilities', 'access', 'parking']
  },
  
  contact: {
    content: `Contact Information:
- Sales Team Phone: 01288 361940
- Mobile Contact: 07496 537633
- VIP Viewings: Book online at whalesboroughliving.co.uk
- Address: Whalesborough Farm, Marhamchurch, Bude, EX23 0JD

VIP Viewing Experience:
1. Lodge tour to showcase property
2. Full resort walkthrough to demonstrate amenities
3. Q&A and investment discussion
4. Flexible scheduling around meals or spa time`,
    keywords: ['contact', 'phone', 'viewing', 'book', 'visit', 'tour', 'appointment']
  }
};

export class FallbackKBService {
  findRelevantContent(query: string): string[] {
    const queryLower = query.toLowerCase();
    const relevantSections: string[] = [];
    
    Object.entries(TRELOWEN_KNOWLEDGE_BASE).forEach(([section, data]) => {
      const hasKeywordMatch = data.keywords.some(keyword => 
        queryLower.includes(keyword.toLowerCase())
      );
      
      if (hasKeywordMatch) {
        relevantSections.push(data.content);
      }
    });
    
    // If no specific matches, return general info
    if (relevantSections.length === 0) {
      relevantSections.push(TRELOWEN_KNOWLEDGE_BASE.features.content);
    }
    
    return relevantSections;
  }
  
  getContextualResponse(query: string): string {
    const relevantContent = this.findRelevantContent(query);
    
    if (relevantContent.length === 0) {
      return '';
    }
    
    return `Based on the following information about Trelowen Lodges:\n\n${relevantContent.join('\n\n')}\n\n`;
  }
}

export const fallbackKBService = new FallbackKBService();
