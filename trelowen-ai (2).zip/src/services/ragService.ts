
import fs from 'fs-extra';
import path from 'path';
import { createEmbedding } from '../utils/openai';
import { logger } from '../utils/logger';
import { fallbackKBService } from './fallbackKB';
import { KnowledgeChunk } from '../embeddings/buildKB';

class RAGService {
  private knowledgeBase: KnowledgeChunk[] = [];
  private isInitialized = false;
  private useEmbeddings = true;

  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      const kbPath = path.join(__dirname, '../../data/knowledge_base.json');
      
      if (await fs.pathExists(kbPath)) {
        this.knowledgeBase = await fs.readJson(kbPath);
        logger.info(`Loaded knowledge base with ${this.knowledgeBase.length} chunks`);
        this.useEmbeddings = true;
      } else {
        logger.warn('Knowledge base not found. Using fallback keyword-based search.');
        this.useEmbeddings = false;
      }
      
      this.isInitialized = true;
    } catch (error) {
      logger.error('Error initializing RAG service:', error);
      this.useEmbeddings = false;
      this.isInitialized = true;
    }
  }

  private cosineSimilarity(a: number[], b: number[]): number {
    const dotProduct = a.reduce((sum, val, i) => sum + val * b[i], 0);
    const magnitudeA = Math.sqrt(a.reduce((sum, val) => sum + val * val, 0));
    const magnitudeB = Math.sqrt(b.reduce((sum, val) => sum + val * val, 0));
    return dotProduct / (magnitudeA * magnitudeB);
  }

  async findRelevantContext(query: string, topK: number = 3): Promise<string[]> {
    if (!this.isInitialized) {
      await this.initialize();
    }

    // Use fallback if embeddings not available
    if (!this.useEmbeddings || this.knowledgeBase.length === 0) {
      return fallbackKBService.findRelevantContent(query);
    }

    try {
      const queryEmbedding = await createEmbedding(query);
      
      const similarities = this.knowledgeBase.map(chunk => ({
        chunk,
        similarity: this.cosineSimilarity(queryEmbedding, chunk.embedding)
      }));

      similarities.sort((a, b) => b.similarity - a.similarity);
      
      return similarities
        .slice(0, topK)
        .filter(item => item.similarity > 0.7) // Only include highly relevant chunks
        .map(item => item.chunk.content);
        
    } catch (error) {
      logger.error('Error finding relevant context, falling back to keyword search:', error);
      return fallbackKBService.findRelevantContent(query);
    }
  }

  async getContextualResponse(query: string): Promise<string> {
    if (!this.useEmbeddings) {
      return fallbackKBService.getContextualResponse(query);
    }

    const relevantContext = await this.findRelevantContext(query);
    
    if (relevantContext.length === 0) {
      return fallbackKBService.getContextualResponse(query);
    }

    return `Based on the following information about Trelowen Lodges:\n\n${relevantContext.join('\n\n')}\n\n`;
  }
}

export const ragService = new RAGService();
