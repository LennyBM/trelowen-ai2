
import axios from 'axios';
import { logger } from '../utils/logger';

interface GHLContact {
  id: string;
  firstName?: string;
  lastName?: string;
  email?: string;
  phone?: string;
  customFields?: Record<string, any>;
}

interface GHLMessage {
  id: string;
  body: string;
  direction: 'inbound' | 'outbound';
  timestamp: string;
}

class GHLService {
  private apiKey: string;
  private locationId: string;
  private baseURL = 'https://services.leadconnectorhq.com';

  constructor() {
    this.apiKey = process.env.GHL_API_KEY || '';
    this.locationId = process.env.GHL_LOCATION_ID || '';
    
    if (!this.apiKey || !this.locationId) {
      logger.warn('GHL API key or location ID not configured');
    }
  }

  private getHeaders() {
    return {
      'Authorization': `Bearer ${this.apiKey}`,
      'Content-Type': 'application/json',
      'Version': '2021-07-28'
    };
  }

  async getContact(contactId: string): Promise<GHLContact | null> {
    try {
      const response = await axios.get(
        `${this.baseURL}/contacts/${contactId}`,
        { headers: this.getHeaders() }
      );
      return response.data.contact;
    } catch (error) {
      logger.error('Error fetching GHL contact:', error);
      return null;
    }
  }

  async updateContactFields(contactId: string, fields: Record<string, any>): Promise<boolean> {
    try {
      const customFields = Object.entries(fields)
        .filter(([_, value]) => value !== undefined && value !== null)
        .reduce((acc, [key, value]) => {
          acc[key] = value;
          return acc;
        }, {} as Record<string, any>);

      await axios.put(
        `${this.baseURL}/contacts/${contactId}`,
        { customFields },
        { headers: this.getHeaders() }
      );

      logger.info(`Updated contact ${contactId} with fields:`, customFields);
      return true;
    } catch (error) {
      logger.error('Error updating GHL contact fields:', error);
      return false;
    }
  }

  async sendMessage(contactId: string, message: string, type: 'SMS' | 'Email' = 'SMS'): Promise<boolean> {
    try {
      const endpoint = type === 'SMS' ? 'conversations/messages' : 'conversations/messages';
      
      await axios.post(
        `${this.baseURL}/${endpoint}`,
        {
          type: type.toLowerCase(),
          contactId,
          message
        },
        { headers: this.getHeaders() }
      );

      logger.info(`Sent ${type} message to contact ${contactId}`);
      return true;
    } catch (error) {
      logger.error(`Error sending ${type} message:`, error);
      return false;
    }
  }

  async getConversationHistory(contactId: string, limit: number = 20): Promise<GHLMessage[]> {
    try {
      const response = await axios.get(
        `${this.baseURL}/conversations/search?contactId=${contactId}&limit=${limit}`,
        { headers: this.getHeaders() }
      );

      return response.data.conversations?.[0]?.messages || [];
    } catch (error) {
      logger.error('Error fetching conversation history:', error);
      return [];
    }
  }

  async createTask(contactId: string, title: string, description: string, dueDate?: Date): Promise<boolean> {
    try {
      await axios.post(
        `${this.baseURL}/contacts/${contactId}/tasks`,
        {
          title,
          body: description,
          dueDate: dueDate?.toISOString()
        },
        { headers: this.getHeaders() }
      );

      logger.info(`Created task for contact ${contactId}: ${title}`);
      return true;
    } catch (error) {
      logger.error('Error creating GHL task:', error);
      return false;
    }
  }

  async addContactToWorkflow(contactId: string, workflowId: string): Promise<boolean> {
    try {
      await axios.post(
        `${this.baseURL}/contacts/${contactId}/workflow/${workflowId}`,
        {},
        { headers: this.getHeaders() }
      );

      logger.info(`Added contact ${contactId} to workflow ${workflowId}`);
      return true;
    } catch (error) {
      logger.error('Error adding contact to workflow:', error);
      return false;
    }
  }

  async createOpportunity(contactId: string, title: string, value: number, stage: string): Promise<string | null> {
    try {
      const response = await axios.post(
        `${this.baseURL}/opportunities`,
        {
          title,
          contactId,
          monetaryValue: value,
          pipelineStageId: stage,
          status: 'open'
        },
        { headers: this.getHeaders() }
      );

      const opportunityId = response.data.opportunity?.id;
      logger.info(`Created opportunity ${opportunityId} for contact ${contactId}`);
      return opportunityId;
    } catch (error) {
      logger.error('Error creating opportunity:', error);
      return null;
    }
  }

  async findContactByEmail(email: string): Promise<GHLContact | null> {
    try {
      const response = await axios.get(
        `${this.baseURL}/contacts/search?email=${encodeURIComponent(email)}`,
        { headers: this.getHeaders() }
      );
      
      const contacts = response.data.contacts || [];
      return contacts.length > 0 ? contacts[0] : null;
    } catch (error) {
      logger.error('Error finding contact by email:', error);
      return null;
    }
  }

  async findContactByPhone(phone: string): Promise<GHLContact | null> {
    try {
      const response = await axios.get(
        `${this.baseURL}/contacts/search?phone=${encodeURIComponent(phone)}`,
        { headers: this.getHeaders() }
      );
      
      const contacts = response.data.contacts || [];
      return contacts.length > 0 ? contacts[0] : null;
    } catch (error) {
      logger.error('Error finding contact by phone:', error);
      return null;
    }
  }

  async updateContact(contactId: string, updateData: Partial<GHLContact>): Promise<boolean> {
    try {
      await axios.put(
        `${this.baseURL}/contacts/${contactId}`,
        updateData,
        { headers: this.getHeaders() }
      );
      
      logger.info(`Updated contact ${contactId}`);
      return true;
    } catch (error) {
      logger.error('Error updating contact:', error);
      return false;
    }
  }
}

export const ghlService = new GHLService();
