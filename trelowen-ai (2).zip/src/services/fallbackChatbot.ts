import { logger } from '../utils/logger';

interface ChatResponse {
  response: string;
  confidence: number;
  category: string;
}

export class FallbackChatbot {
  private responses = {
    pricing: {
      patterns: ['price', 'cost', 'how much', 'payment', 'deposit', 'financing', 'service charge', 'annual'],
      response: `Our Trelowen Lodge prices are:

🏡 **2-Bedroom Lodge**: £425,000 (fully furnished & turnkey ready)
🏡 **3-Bedroom Lodge**: £450,000 (fully furnished & turnkey ready)  
🏡 **4-Bedroom Lodge**: £475,000 (fully furnished & turnkey ready)

**Payment Terms:**
- Reservation Deposit: £5,000 to reserve your lodge
- Full payment due prior to completion
- No current in-house financing available

**Annual Service Charges:**
- With Sublet Service: £6,500 annually (includes full rental management)
- Without Sublet Service: £8,500 annually (you manage rentals independently)

Would you like to book a VIP viewing to see these beautiful lodges in person? Call us at 01288 361940 or visit whalesboroughliving.co.uk`
    },

    investment: {
      patterns: ['investment', 'yield', 'roi', 'return', 'rental', 'income', 'profit'],
      response: `Trelowen Lodges offer excellent investment opportunities:

💰 **Investment Benefits:**
- Strong ROI potential with professional management
- Passive income through our comprehensive sublet service
- Capital growth in sought-after Cornwall market
- 12-month year-round access for personal use
- Professional hands-off rental management available

**Owner Benefits:**
- Dining discounts at all resort bars and restaurants
- 20% off spa treatments and products
- 10% discount on water sports equipment hire
- Exclusive owner-only events
- Free super-fast Wi-Fi throughout resort

For detailed yield information and investment calculations, I'd recommend booking a personal consultation. Call us at 01288 361940 to discuss your investment goals.`
    },

    features: {
      patterns: ['features', 'eco-friendly', 'solar', 'furnished', 'turnkey', 'electric', 'green', 'what comes with'],
      response: `Our Trelowen Lodges are premium eco-friendly properties with amazing features:

🌱 **Eco-Friendly Features:**
- Fully electric (no gas) - completely eco-friendly setup
- Solar powered with integrated roof solar panels
- Green roofs with flowerbed roofs and rainwater collection
- High-spec interiors with premium finishes throughout

🏠 **Fully Furnished & Turnkey Ready:**
- Complete furniture pack (beds, sofas, wardrobes, dining sets)
- Kitchen essentials (plates, mugs, glassware, cutlery, cookware)
- All kitchen appliances included
- **Key point: "Just bring your suitcase – everything else is ready!"**

Would you like to see these features in person? Book a VIP viewing at whalesboroughliving.co.uk or call 01288 361940.`
    },

    location: {
      patterns: ['location', 'cornwall', 'bude', 'resort', 'spa', 'facilities', 'access', 'parking', 'where'],
      response: `Trelowen Lodges are perfectly located in beautiful North Cornwall:

📍 **Location:**
Whalesborough Farm, Marhamchurch, Bude, EX23 0JD, North Cornwall

🏖️ **Resort Features (all 1-minute walk):**
- The W Club Spa
- Swimming Pool
- The Weir Restaurant
- State-of-the-art Gym

🚗 **Access & Parking:**
- ANPR gate system with 24/7 secure access
- Dedicated signposted car park spaces
- Close proximity to all lodges

**Why North Cornwall?**
- Prestigious location in England's most desirable coastal regions
- Close to popular seaside town of Bude
- Surrounded by Cornwall's stunning landscapes
- High demand location for holiday rentals

Ready to experience this amazing location? Book your VIP viewing today at 01288 361940!`
    },

    contact: {
      patterns: ['contact', 'phone', 'viewing', 'book', 'visit', 'tour', 'appointment', 'call'],
      response: `I'd love to help you arrange a visit to see our beautiful Trelowen Lodges!

📞 **Contact Information:**
- Sales Team Phone: **01288 361940**
- Mobile Contact: **07496 537633**
- Online Booking: **whalesboroughliving.co.uk**

🌟 **VIP Viewing Experience:**
1. Personal lodge tour to showcase the property
2. Full resort walkthrough to demonstrate all amenities
3. Q&A session and investment discussion
4. Flexible scheduling around meals or spa time

**Address:** Whalesborough Farm, Marhamchurch, Bude, EX23 0JD

Our VIP viewings are the best way to experience the quality and location of Trelowen Lodges. We can arrange flexible timing to suit your schedule. Would you like me to help you book a viewing?`
    },

    greeting: {
      patterns: ['hello', 'hi', 'hey', 'good morning', 'good afternoon', 'good evening'],
      response: `Hello! Welcome to Trelowen Lodges! 👋

I'm here to help you learn about our premium eco-friendly luxury lodges at Whalesborough Resort & Spa in beautiful North Cornwall.

Our lodges offer:
🏡 Fully furnished, turnkey-ready properties (£425k-£475k)
🌱 100% eco-friendly with solar power and green roofs
💰 Strong investment potential with professional management
🏖️ Amazing location just 1 minute from spa, pool & restaurant

What would you like to know about Trelowen Lodges? I can help with pricing, features, investment information, or booking a VIP viewing!`
    },

    general: {
      patterns: ['tell me about', 'what is', 'information', 'details'],
      response: `Trelowen Lodges are premium eco-friendly luxury lodges at Whalesborough Resort & Spa in North Cornwall.

**Key Highlights:**
🏡 **Property Type:** Long leasehold ownership (not holiday park licensing)
💰 **Prices:** 2-bed £425k, 3-bed £450k, 4-bed £475k (fully furnished)
🌱 **Eco-Friendly:** Solar powered, electric only, green roofs
📍 **Location:** Whalesborough Resort, North Cornwall (EX23 0JD)
🏊 **Facilities:** 1-minute walk to spa, pool, restaurant, gym
📅 **Access:** 12-month year-round access for owners

**Perfect for:**
- Property investors seeking strong ROI
- Those wanting a luxury Cornwall retreat
- Eco-conscious buyers
- Anyone seeking turnkey investment properties

Would you like specific information about pricing, features, investment returns, or booking a viewing? I'm here to help!`
    }
  };

  findBestResponse(message: string): ChatResponse {
    const messageLower = message.toLowerCase();
    let bestMatch = { category: 'general', confidence: 0 };

    // Check each category for pattern matches
    for (const [category, data] of Object.entries(this.responses)) {
      let matches = 0;
      for (const pattern of data.patterns) {
        if (messageLower.includes(pattern.toLowerCase())) {
          matches++;
        }
      }
      
      const confidence = matches / data.patterns.length;
      if (confidence > bestMatch.confidence) {
        bestMatch = { category, confidence };
      }
    }

    // If no good match found, use general response
    if (bestMatch.confidence < 0.1) {
      bestMatch.category = 'general';
      bestMatch.confidence = 0.5;
    }

    return {
      response: this.responses[bestMatch.category as keyof typeof this.responses].response,
      confidence: bestMatch.confidence,
      category: bestMatch.category
    };
  }

  generateResponse(message: string): string {
    try {
      const result = this.findBestResponse(message);
      
      logger.info('Fallback chatbot response', {
        message,
        category: result.category,
        confidence: result.confidence
      });

      return result.response;
    } catch (error) {
      logger.error('Error in fallback chatbot:', error);
      return `Thank you for your interest in Trelowen Lodges! I'd be happy to help you learn more about our premium eco-friendly luxury lodges in North Cornwall.

For immediate assistance, please call our sales team at **01288 361940** or visit **whalesboroughliving.co.uk** to book a VIP viewing.

Our lodges start from £425,000 and offer excellent investment potential with 12-month year-round access. What specific information can I help you with?`;
    }
  }
}

export const fallbackChatbot = new FallbackChatbot();
