
import { ghlService } from './ghlService';
import { generateChatResponse } from '../utils/openai';
import { logger } from '../utils/logger';

interface FollowUpContext {
  contactId: string;
  leadInsights?: any;
  lastInteraction?: string;
  interactionType?: string;
}

class FollowUpService {
  async scheduleInitialFollowUp(contactId: string): Promise<void> {
    try {
      // Schedule task for 24 hours later
      const followUpDate = new Date();
      followUpDate.setHours(followUpDate.getHours() + 24);

      await ghlService.createTask(
        contactId,
        'Initial Follow-up Call',
        'New lead - make initial contact call to introduce Trelowen and assess interest level',
        followUpDate
      );

      logger.info(`Scheduled initial follow-up for contact: ${contactId}`);
    } catch (error) {
      logger.error('Error scheduling initial follow-up:', error);
    }
  }

  async scheduleHighPriorityFollowUp(contactId: string, leadInsights: any): Promise<void> {
    try {
      // Schedule immediate follow-up for high-value leads
      const followUpDate = new Date();
      followUpDate.setHours(followUpDate.getHours() + 2);

      const taskDescription = `HIGH PRIORITY LEAD - Qualification Score: ${leadInsights.qualificationScore || 'High'}
Budget Range: ${leadInsights.budgetRange || 'Unknown'}
Interest Type: ${leadInsights.interestType || 'Unknown'}
Customer Stage: ${leadInsights.customerStage || 'Unknown'}
Urgency: ${leadInsights.urgency || 'Unknown'}

Action: Call immediately to arrange VIP viewing`;

      await ghlService.createTask(
        contactId,
        'HIGH PRIORITY: Immediate Follow-up',
        taskDescription,
        followUpDate
      );

      logger.info(`Scheduled high priority follow-up for contact: ${contactId}`);
    } catch (error) {
      logger.error('Error scheduling high priority follow-up:', error);
    }
  }

  async scheduleFormFollowUp(contactId: string, formData: any): Promise<void> {
    try {
      // Schedule follow-up within 1 hour for form submissions
      const followUpDate = new Date();
      followUpDate.setHours(followUpDate.getHours() + 1);

      const taskDescription = `Form Submission Follow-up
Form: ${formData.formName || 'Unknown'}
Submission Details: ${JSON.stringify(formData.submission, null, 2)}

Action: Call to discuss their specific interests and arrange viewing`;

      await ghlService.createTask(
        contactId,
        'Form Submission Follow-up',
        taskDescription,
        followUpDate
      );

      logger.info(`Scheduled form follow-up for contact: ${contactId}`);
    } catch (error) {
      logger.error('Error scheduling form follow-up:', error);
    }
  }

  async generatePersonalizedFollowUp(context: FollowUpContext): Promise<string> {
    try {
      const contact = await ghlService.getContact(context.contactId);
      
      const prompt = `Generate a personalized follow-up message for a Trelowen Lodges prospect.

Contact Details:
- Name: ${contact?.firstName || 'Prospect'}
- Last Interaction: ${context.lastInteraction || 'Initial inquiry'}
- Interaction Type: ${context.interactionType || 'Website chat'}

Lead Insights:
${context.leadInsights ? JSON.stringify(context.leadInsights, null, 2) : 'No specific insights available'}

Create a warm, personalized follow-up message that:
1. References their previous interaction
2. Provides value based on their interests
3. Addresses any concerns they might have
4. Includes a clear call-to-action (VIP viewing)
5. Maintains the luxury, professional tone

Keep it conversational and under 200 words.`;

      return await generateChatResponse([{ role: 'user', content: prompt }]);
    } catch (error) {
      logger.error('Error generating personalized follow-up:', error);
      return `Hi ${context.contactId}, thank you for your interest in Trelowen Lodges. I'd love to arrange a VIP viewing for you to experience our luxury eco-friendly lodges firsthand. Please call us at 01288 361940 or visit whalesboroughliving.co.uk to book your viewing.`;
    }
  }

  async sendScheduledFollowUp(contactId: string, context: FollowUpContext): Promise<void> {
    try {
      const followUpMessage = await this.generatePersonalizedFollowUp(context);
      await ghlService.sendMessage(contactId, followUpMessage);
      
      logger.info(`Sent scheduled follow-up to contact: ${contactId}`);
    } catch (error) {
      logger.error('Error sending scheduled follow-up:', error);
    }
  }

  async scheduleViewingReminder(contactId: string, viewingDate: Date): Promise<void> {
    try {
      // Schedule reminder 24 hours before viewing
      const reminderDate = new Date(viewingDate);
      reminderDate.setHours(reminderDate.getHours() - 24);

      await ghlService.createTask(
        contactId,
        'VIP Viewing Reminder',
        `Send viewing reminder and confirmation details for ${viewingDate.toLocaleDateString()}`,
        reminderDate
      );

      logger.info(`Scheduled viewing reminder for contact: ${contactId}`);
    } catch (error) {
      logger.error('Error scheduling viewing reminder:', error);
    }
  }
}

export const followUpService = new FollowUpService();
