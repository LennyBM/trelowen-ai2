
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';
import path from 'path';
import { logger } from './utils/logger';
import chatRoutes from './routes/chat';
import ghlWebhookRoutes from './routes/ghlWebhook';
import smsRoutes from './routes/sms';
// import fbMessengerRoutes from './routes/fbMessenger';
import emailRoutes from './routes/email';
import investmentRoutes from './routes/investment';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Security middleware
app.use(helmet());
app.use(cors({
  origin: process.env.NODE_ENV === 'production' ? [
    'https://loveable.dev',
    'https://*.loveable.dev',
    'https://trelowen.loveable.dev',
    'https://www.trelowen.com',
    'https://trelowen.com'
  ] : true,
  credentials: true
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again later.'
});
app.use(limiter);

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString(),
    service: 'Trelowen AI Assistant'
  });
});

// Static files for chat widget
app.use('/widget', express.static(path.join(__dirname, '../widget')));

// API routes
app.use('/api/chat', chatRoutes);
app.use('/api/ghl-webhook', ghlWebhookRoutes);
app.use('/api/sms', smsRoutes);
// app.use('/api/fb-messenger', fbMessengerRoutes);
app.use('/api/email', emailRoutes);
app.use('/api/investment', investmentRoutes);

// Error handling middleware
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  logger.error('Unhandled error:', err);
  res.status(500).json({ 
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong'
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

app.listen(PORT, () => {
  logger.info(`Trelowen AI Assistant server running on port ${PORT}`);
  logger.info(`Health check available at: http://localhost:${PORT}/api/health`);
});

export default app;
