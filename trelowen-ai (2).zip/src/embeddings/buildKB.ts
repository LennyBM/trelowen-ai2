
import fs from 'fs-extra';
import path from 'path';
import { createEmbedding } from '../utils/openai';
import { logger } from '../utils/logger';

interface KnowledgeChunk {
  id: string;
  content: string;
  embedding: number[];
  metadata: {
    source: string;
    section: string;
    type: string;
  };
}

const KNOWLEDGE_BASE_SECTIONS = [
  {
    title: "Business Overview",
    content: `Trelowen Lodges are premium eco-friendly luxury lodges located at Whalesborough Resort & Spa in North Cornwall. These are ownership properties (not rental), offering investors the opportunity to own a fully furnished, turnkey-ready lodge with strong ROI potential and year-round access.

Location: Whalesborough Farm, Marhamchurch, Bude, EX23 0JD, North Cornwall, England

Resort Features:
- The W Club Spa (1-minute walk from lodges)
- Swimming Pool (1-minute walk)
- The Weir Restaurant (1-minute walk)
- State-of-the-art Gym (1-minute walk)
- Premium resort facilities and amenities

Property Development: 67-lodge development field, located on former tennis courts area, directly behind The W Club car park. Trelowen and Tevi lodges have no structural differences, just different development phases.

Business Model: Long leasehold ownership (not holiday park licensing) with 12-month year-round access for owners. Optional fully managed sublet service available.`
  },
  {
    title: "Pricing Information",
    content: `Current Lodge Prices (2024):
- 2-Bedroom Lodge: £425,000 (fully furnished & turnkey ready)
- 3-Bedroom Lodge: £450,000 (fully furnished & turnkey ready)  
- 4-Bedroom Lodge: £475,000 (fully furnished & turnkey ready)

Payment Terms:
- Reservation Deposit: £5,000 to reserve lodge
- Payment Structure: Full payment due prior to completion
- Financing: No current in-house financing available
- External Financing: Buyers arrange external financing independently
- Future Development: Working on finance approval options for future

Annual Service Charges:
- With Sublet Service: £6,500 annually (includes full rental management)
- Without Sublet Service: £8,500 annually (owner manages rentals independently)

Target Budget Range: £275,000 - £1,000,000+ (accommodates various buyer profiles from first-time lodge buyers to luxury property investors)`
  },
  {
    title: "Investment Details",
    content: `Rental Yield: Approximately 8% rental yield (yield figures are not advertised publicly and are only discussed in personal consultations based on current market performance)

Investment Benefits:
- Strong ROI Potential: Discussed individually in 1:1 conversations
- Passive Income: Available through comprehensive sublet service
- Capital Growth: Premium location in sought-after Cornwall market
- Year-Round Usage: 12-month access for personal use
- Professional Management: Optional hands-off rental management

Sublet Service Features:
Guest Management: Property listing & marketing, booking management, guest communications, check-in/check-out services
Property Maintenance: Professional cleaning, changeover management, maintenance coordination, regular income reports

Owner Benefits:
- Dining Discounts: Discounts at all resort bars and restaurants
- Spa Benefits: 20% off treatments and products
- Water Sports: 10% discount on equipment hire
- Exclusive Events: Designated owner-only events
- Local Attractions: Discounts at restaurants & attractions
- Connectivity: Free super-fast Wi-Fi throughout resort`
  },
  {
    title: "Property Features",
    content: `Technical Specifications:
- Fully Electric: No gas - completely eco-friendly setup
- Solar Powered: Integrated roof solar panels
- Green Roofs: Flowerbed roofs with rainwater collection
- High-Spec Interiors: Premium finishes throughout

"Fully Furnished & Turnkey Ready" Includes:
Complete Furniture Pack: Beds & mattresses, sofas & armchairs, wardrobes & storage, dining tables & chairs
Kitchen Essentials: Plates, mugs, glassware, cutlery sets, cookware & utensils, kitchen appliances

Key Selling Point: "Just bring your suitcase – everything else is ready!"

Lodge Configurations:
- 2-Bedroom Lodge: £425,000
- 3-Bedroom Lodge: £450,000
- 4-Bedroom Lodge: £475,000

All lodges feature the same high-quality specifications and eco-friendly features regardless of size.`
  },
  {
    title: "Location Benefits",
    content: `Cornwall Location Advantages:
- North Cornwall: Prestigious location in one of England's most desirable coastal regions
- Bude Proximity: Close to the popular seaside town of Bude
- Natural Beauty: Surrounded by Cornwall's stunning landscapes
- Tourism Appeal: High demand location for holiday rentals

Resort Accessibility:
- Address: Whalesborough Farm, Marhamchurch, Bude, EX23 0JD
- Access System: ANPR (Automatic Number Plate Recognition) gate system
- Security: Secure, contactless entry with 24/7 access for registered owners
- Navigation: Clear signage for easy navigation throughout resort

Parking Arrangements:
- Parking: Dedicated signposted car park spaces
- Proximity: Close proximity to all lodges
- Note: No direct parking outside each individual lodge

Nearby Attractions: Access to Cornwall's renowned beaches, coastal walking paths, local restaurants and attractions (with owner discounts), rich cultural heritage and natural landmarks.`
  },
  {
    title: "Sales Process",
    content: `Typical Sales Timeline:
1. Fast Sales: 3-4 weeks (e.g., Webbers referrals)
2. Standard Timeline: 2-3 months
3. Extended Timeline: Multiple viewings may extend timeline
4. Variable Factors: Timeline varies by buyer readiness

6-Step Sales Process:
Step 1: Enquiry Received - Initial interest captured through various channels
Step 2: Auto Email Sent - Information package delivered automatically
Step 3: Follow-up Call - Personal contact if no initial reply
Step 4: VIP Viewing - Lodge & full resort tour arranged
Step 5: Proposal - Pricing & terms discussed in detail
Step 6: Completion - Decision & payment processing

VIP Viewing Experience Structure:
1. Arrange suitable time for guest preferences
2. Plan around meals or spa time for enhanced experience
3. Conduct lodge tour first to showcase property
4. Full resort walkthrough to demonstrate amenities
5. Final Q&A and investment discussion to address concerns

Lead Call Approach: No fixed script - relaxed, tailored conversations. Discussion topics include timing, interests, and availability. Visits arranged according to guest preferences.`
  },
  {
    title: "Contact Information",
    content: `Primary Contact Details:
- Sales Team Phone: 01288 361940
- Mobile Contact: 07496 537633
- VIP Viewings: Book online at whalesboroughliving.co.uk

Booking VIP Viewings:
1. Phone: Call our sales team directly
2. Online: Visit whalesboroughliving.co.uk
3. Mobile: Direct contact for immediate assistance

Lead Generation Channels:
- Facebook Ads: Primary digital advertising channel
- Estate Agent Network: Referrals from partners like Webbers
- On-Site Engagement: Converting holidaymakers to buyers

Follow-up Process: Currently using manual call and email reminders with plans to develop automated nurture sequences for systematic lead nurturing.`
  }
];

async function buildKnowledgeBase(): Promise<void> {
  try {
    logger.info('Building Trelowen knowledge base...');
    
    const knowledgeChunks: KnowledgeChunk[] = [];
    
    for (let i = 0; i < KNOWLEDGE_BASE_SECTIONS.length; i++) {
      const section = KNOWLEDGE_BASE_SECTIONS[i];
      logger.info(`Processing section: ${section.title}`);
      
      const embedding = await createEmbedding(section.content);
      
      const chunk: KnowledgeChunk = {
        id: `section_${i}`,
        content: section.content,
        embedding,
        metadata: {
          source: 'trelowen_configuration',
          section: section.title,
          type: 'business_knowledge'
        }
      };
      
      knowledgeChunks.push(chunk);
      
      // Add delay to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    // Ensure data directory exists
    await fs.ensureDir(path.join(__dirname, '../../data'));
    
    // Save knowledge base
    const kbPath = path.join(__dirname, '../../data/knowledge_base.json');
    await fs.writeJson(kbPath, knowledgeChunks, { spaces: 2 });
    
    logger.info(`Knowledge base built successfully with ${knowledgeChunks.length} chunks`);
    logger.info(`Saved to: ${kbPath}`);
    
  } catch (error) {
    logger.error('Error building knowledge base:', error);
    throw error;
  }
}

// Run if called directly
if (require.main === module) {
  buildKnowledgeBase()
    .then(() => {
      logger.info('Knowledge base build completed');
      process.exit(0);
    })
    .catch((error) => {
      logger.error('Knowledge base build failed:', error);
      process.exit(1);
    });
}

export { buildKnowledgeBase, KnowledgeChunk };
