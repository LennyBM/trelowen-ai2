
import express from 'express';
import crypto from 'crypto';
import { generateChatResponse } from '../utils/openai';
import { ghlService } from '../services/ghlService';
import { leadIntelligenceService } from '../services/leadIntelligence';

const router = express.Router();

// Verify webhook signature
function verifyWebhookSignature(payload: string, signature: string): boolean {
  const expectedSignature = crypto
    .createHmac('sha256', process.env.GHL_WEBHOOK_SECRET || '')
    .update(payload)
    .digest('hex');
  
  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expectedSignature)
  );
}

// Handle GHL webhooks
router.post('/', async (req, res) => {
  try {
    const signature = req.headers['x-ghl-signature'] as string;
    const payload = JSON.stringify(req.body);
    
    // Verify webhook signature
    if (!verifyWebhookSignature(payload, signature)) {
      return res.status(401).json({ error: 'Invalid signature' });
    }
    
    const { type, data } = req.body;
    
    switch (type) {
      case 'ContactCreate':
        await handleContactCreate(data);
        break;
      case 'ContactUpdate':
        await handleContactUpdate(data);
        break;
      case 'InboundMessage':
        await handleInboundMessage(data);
        break;
      case 'OpportunityCreate':
        await handleOpportunityCreate(data);
        break;
      case 'OpportunityUpdate':
        await handleOpportunityUpdate(data);
        break;
      default:
        console.log('Unhandled webhook type:', type);
    }
    
    res.status(200).json({ success: true });
  } catch (error) {
    console.error('GHL webhook error:', error);
    res.status(500).json({ error: 'Failed to process webhook' });
  }
});

async function handleContactCreate(data: any) {
  console.log('New contact created:', data.contact);
  
  // Analyze any initial message or form data for lead intelligence
  if (data.contact.source || data.contact.customFields) {
    const leadData = await leadIntelligenceService.analyzeConversation(
      JSON.stringify(data.contact)
    );
    
    if (leadData) {
      await ghlService.updateContact(data.contact.id, {
        customFields: {
          investment_budget: leadData.budgetRange,
          property_type_interest: leadData.interestType,
          customer_stage: leadData.customerStage,
          urgency_level: leadData.urgency
        }
      });
    }
  }
}

async function handleContactUpdate(data: any) {
  console.log('Contact updated:', data.contact);
}

async function handleInboundMessage(data: any) {
  try {
    const { contact, message, conversation } = data;
    
    // Get conversation history
    const conversationHistory = await ghlService.getConversationHistory(conversation.id);
    
    // Analyze message for lead intelligence
    const leadData = await leadIntelligenceService.analyzeConversation(
      message.body,
      conversationHistory
    );
    
    // Update contact with lead intelligence
    if (leadData) {
      await ghlService.updateContact(contact.id, {
        customFields: {
          investment_budget: leadData.budgetRange,
          property_type_interest: leadData.interestType,
          customer_stage: leadData.customerStage,
          urgency_level: leadData.urgency
        }
      });
    }
    
    // Get updated contact info for context
    const contactInfo = await ghlService.getContact(contact.id);
    let contextualInfo = '';
    
    if (contactInfo) {
      contextualInfo = `Contact: ${contactInfo.firstName} ${contactInfo.lastName}`;
      if (contactInfo.customFields) {
        const investmentBudget = contactInfo.customFields['investment_budget'];
        const propertyType = contactInfo.customFields['property_type_interest'];
        const timeline = contactInfo.customFields['investment_timeline'];
        
        if (investmentBudget) contextualInfo += `, Budget: ${investmentBudget}`;
        if (propertyType) contextualInfo += `, Interest: ${propertyType}`;
        if (timeline) contextualInfo += `, Timeline: ${timeline}`;
      }
    }
    
    // Generate AI response
    const aiResponse = await generateChatResponse([
      ...conversationHistory.map((msg: any) => ({ 
        role: (msg.direction === 'inbound' ? 'user' : 'assistant') as 'user' | 'assistant' | 'system', 
        content: String(msg.body) 
      })),
      { role: 'user' as const, content: String(message.body) }
    ], `You are the Trelowen AI assistant. ${contextualInfo ? `Context: ${contextualInfo}` : ''}`);
    
    // Send response back through GHL
    // Note: This would require GHL API integration to send messages
    console.log('AI Response generated:', aiResponse);
    
  } catch (error) {
    console.error('Error handling inbound message:', error);
  }
}

async function handleOpportunityCreate(data: any) {
  console.log('New opportunity created:', data.opportunity);
}

async function handleOpportunityUpdate(data: any) {
  console.log('Opportunity updated:', data.opportunity);
}

export default router;
