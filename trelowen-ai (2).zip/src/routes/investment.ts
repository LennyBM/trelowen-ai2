
import express from 'express';
import { generateChatResponse } from '../utils/openai';
import { logger } from '../utils/logger';

const router = express.Router();

interface InvestmentCalculationRequest {
  lodgePrice: number;
  lodgeType: '2-bedroom' | '3-bedroom' | '4-bedroom';
  useSubletService: boolean;
  personalUseDays?: number;
  expectedOccupancy?: number;
  additionalCosts?: number;
}

interface InvestmentResult {
  annualRevenue: number;
  annualCosts: number;
  netIncome: number;
  roi: number;
  paybackPeriod: number;
  projections: {
    year1: number;
    year3: number;
    year5: number;
  };
}

// Base rental rates per night (these would typically come from a database)
const RENTAL_RATES = {
  '2-bedroom': { low: 180, high: 320, average: 250 },
  '3-bedroom': { low: 220, high: 380, average: 300 },
  '4-bedroom': { low: 260, high: 450, average: 355 }
};

router.post('/calculate', async (req, res) => {
  try {
    const {
      lodgePrice,
      lodgeType,
      useSubletService,
      personalUseDays = 0,
      expectedOccupancy = 65,
      additionalCosts = 0
    }: InvestmentCalculationRequest = req.body;

    if (!lodgePrice || !lodgeType) {
      return res.status(400).json({ error: 'Lodge price and type are required' });
    }

    const calculation = calculateInvestmentReturns({
      lodgePrice,
      lodgeType,
      useSubletService,
      personalUseDays,
      expectedOccupancy,
      additionalCosts
    });

    // Generate AI explanation
    const explanation = await generateInvestmentExplanation(calculation, {
      lodgePrice,
      lodgeType,
      useSubletService,
      personalUseDays,
      expectedOccupancy
    });

    res.json({
      calculation,
      explanation,
      assumptions: {
        averageNightlyRate: RENTAL_RATES[lodgeType].average,
        occupancyRate: expectedOccupancy,
        serviceCharge: useSubletService ? 6500 : 8500,
        personalUseDays
      },
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    logger.error('Error calculating investment returns:', error);
    res.status(500).json({ error: 'Failed to calculate investment returns' });
  }
});

router.post('/scenarios', async (req, res) => {
  try {
    const { lodgePrice, lodgeType } = req.body;

    if (!lodgePrice || !lodgeType) {
      return res.status(400).json({ error: 'Lodge price and type are required' });
    }

    // Generate multiple scenarios
    const scenarios = [
      {
        name: 'Conservative',
        occupancy: 55,
        personalUse: 14,
        useSubletService: true
      },
      {
        name: 'Realistic',
        occupancy: 65,
        personalUse: 21,
        useSubletService: true
      },
      {
        name: 'Optimistic',
        occupancy: 75,
        personalUse: 14,
        useSubletService: true
      },
      {
        name: 'Self-Managed',
        occupancy: 70,
        personalUse: 28,
        useSubletService: false
      }
    ];

    const scenarioResults = scenarios.map(scenario => ({
      ...scenario,
      calculation: calculateInvestmentReturns({
        lodgePrice,
        lodgeType,
        useSubletService: scenario.useSubletService,
        personalUseDays: scenario.personalUse,
        expectedOccupancy: scenario.occupancy
      })
    }));

    // Generate AI comparison
    const comparison = await generateScenarioComparison(scenarioResults, lodgeType);

    res.json({
      scenarios: scenarioResults,
      comparison,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    logger.error('Error generating investment scenarios:', error);
    res.status(500).json({ error: 'Failed to generate investment scenarios' });
  }
});

function calculateInvestmentReturns(params: InvestmentCalculationRequest): InvestmentResult {
  const {
    lodgePrice,
    lodgeType,
    useSubletService,
    personalUseDays = 0,
    expectedOccupancy = 65,
    additionalCosts = 0
  } = params;

  const rates = RENTAL_RATES[lodgeType];
  const averageRate = rates.average;
  
  // Calculate available rental days (365 - personal use days)
  const availableRentalDays = 365 - personalUseDays;
  
  // Calculate occupied days based on occupancy rate
  const occupiedDays = Math.floor((availableRentalDays * expectedOccupancy) / 100);
  
  // Calculate annual revenue
  const annualRevenue = occupiedDays * averageRate;
  
  // Calculate annual costs
  const serviceCharge = useSubletService ? 6500 : 8500;
  const totalAnnualCosts = serviceCharge + additionalCosts;
  
  // Calculate net income and ROI
  const netIncome = annualRevenue - totalAnnualCosts;
  const roi = (netIncome / lodgePrice) * 100;
  const paybackPeriod = lodgePrice / netIncome;
  
  // Calculate projections (assuming 3% annual growth)
  const projections = {
    year1: netIncome,
    year3: netIncome * Math.pow(1.03, 3),
    year5: netIncome * Math.pow(1.03, 5)
  };

  return {
    annualRevenue,
    annualCosts: totalAnnualCosts,
    netIncome,
    roi,
    paybackPeriod,
    projections
  };
}

async function generateInvestmentExplanation(
  calculation: InvestmentResult,
  params: any
): Promise<string> {
  const prompt = `Generate a clear, professional explanation of this Trelowen Lodge investment calculation:

Investment Details:
- Lodge Price: £${params.lodgePrice.toLocaleString()}
- Lodge Type: ${params.lodgeType}
- Sublet Service: ${params.useSubletService ? 'Yes' : 'No'}
- Personal Use: ${params.personalUseDays} days/year
- Expected Occupancy: ${params.expectedOccupancy}%

Results:
- Annual Revenue: £${calculation.annualRevenue.toLocaleString()}
- Annual Costs: £${calculation.annualCosts.toLocaleString()}
- Net Income: £${calculation.netIncome.toLocaleString()}
- ROI: ${calculation.roi.toFixed(2)}%
- Payback Period: ${calculation.paybackPeriod.toFixed(1)} years

Create an explanation that:
1. Summarizes the key financial metrics
2. Explains what drives the returns
3. Highlights the benefits of the investment
4. Mentions the luxury lifestyle aspects
5. Includes appropriate disclaimers about projections

Keep it professional but accessible, around 200-250 words.`;

  return await generateChatResponse([{ role: 'user', content: prompt }]);
}

async function generateScenarioComparison(scenarios: any[], lodgeType: string): Promise<string> {
  const prompt = `Compare these Trelowen Lodge investment scenarios for a ${lodgeType}:

${scenarios.map(s => `
${s.name} Scenario:
- Occupancy: ${s.occupancy}%
- Personal Use: ${s.personalUse} days
- Sublet Service: ${s.useSubletService ? 'Yes' : 'No'}
- Net Income: £${s.calculation.netIncome.toLocaleString()}
- ROI: ${s.calculation.roi.toFixed(2)}%
`).join('\n')}

Provide a clear comparison that:
1. Highlights the best performing scenario
2. Explains the trade-offs between scenarios
3. Discusses the impact of personal use vs rental income
4. Mentions the benefits of professional management
5. Helps investors choose the right approach

Keep it informative and balanced, around 200 words.`;

  return await generateChatResponse([{ role: 'user', content: prompt }]);
}

export default router;
