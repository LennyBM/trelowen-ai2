
import express from 'express';
import twilio from 'twilio';
import { generateChatResponse } from '../utils/openai';
import { ghlService } from '../services/ghlService';
import { leadIntelligenceService } from '../services/leadIntelligence';

const router = express.Router();

// Initialize Twilio client (optional)
let twilioClient: any = null;
if (process.env.TWILIO_ACCOUNT_SID && 
    process.env.TWILIO_AUTH_TOKEN && 
    process.env.TWILIO_ACCOUNT_SID.startsWith('AC') &&
    process.env.TWILIO_ACCOUNT_SID !== 'your_twilio_account_sid') {
  try {
    twilioClient = twilio(
      process.env.TWILIO_ACCOUNT_SID,
      process.env.TWILIO_AUTH_TOKEN
    );
    console.log('Twilio client initialized successfully');
  } catch (error) {
    console.warn('Twilio not configured properly, SMS functionality disabled');
  }
} else {
  console.log('Twilio credentials not configured, SMS functionality disabled');
}

// Handle incoming SMS
router.post('/webhook', async (req, res) => {
  try {
    const { From, Body, MessageSid } = req.body;
    
    console.log(`Received SMS from ${From}: ${Body}`);
    
    // Find or create contact in GHL
    let contact = await ghlService.findContactByPhone(From);
    
    // Analyze lead intelligence
    const leadData = await leadIntelligenceService.analyzeConversation(Body);
    
    // Update contact with lead intelligence
    if (leadData && contact) {
      await ghlService.updateContact(contact.id, {
        customFields: {
          investment_budget: leadData.budgetRange,
          property_type_interest: leadData.interestType,
          customer_stage: leadData.customerStage,
          urgency_level: leadData.urgency
        }
      });
    }
    
    // Prepare conversation context
    let contextualInfo = '';
    if (contact) {
      contextualInfo = `Contact: ${contact.firstName} ${contact.lastName}`;
      if (contact.customFields) {
        const investmentBudget = contact.customFields['investment_budget'];
        const propertyType = contact.customFields['property_type_interest'];
        const timeline = contact.customFields['investment_timeline'];
        
        if (investmentBudget) contextualInfo += `, Budget: ${investmentBudget}`;
        if (propertyType) contextualInfo += `, Interest: ${propertyType}`;
        if (timeline) contextualInfo += `, Timeline: ${timeline}`;
      }
    }
    
    // Generate system prompt with context
    const systemPrompt = `You are the Trelowen AI assistant for real estate investment opportunities. ${contextualInfo ? `Context: ${contextualInfo}` : ''} Respond helpfully and professionally to SMS inquiries.`;
    
    // Prepare messages for AI
    const messages: { role: 'user' | 'assistant' | 'system'; content: string }[] = [
      // Add conversation history if available
      // For now, just the current message
      { role: 'user', content: String(Body) }
    ];

    const aiResponse = await generateChatResponse(messages, systemPrompt);

    // Send SMS response
    if (twilioClient) {
      await twilioClient.messages.create({
        body: aiResponse,
        from: process.env.TWILIO_PHONE_NUMBER,
        to: From
      });
    } else {
      console.log('SMS response (Twilio not configured):', aiResponse);
    }

    res.status(200).json({ success: true, message: 'SMS processed successfully' });
  } catch (error) {
    console.error('SMS webhook error:', error);
    res.status(500).json({ error: 'Failed to process SMS' });
  }
});

// Send outbound SMS
router.post('/send', async (req, res) => {
  try {
    const { to, message } = req.body;
    
    if (!to || !message) {
      return res.status(400).json({ error: 'Phone number and message are required' });
    }
    
    if (!twilioClient) {
      return res.status(503).json({ error: 'SMS service not configured' });
    }
    
    const result = await twilioClient.messages.create({
      body: message,
      from: process.env.TWILIO_PHONE_NUMBER,
      to: to
    });
    
    res.status(200).json({ 
      success: true, 
      messageSid: result.sid,
      message: 'SMS sent successfully' 
    });
  } catch (error) {
    console.error('Send SMS error:', error);
    res.status(500).json({ error: 'Failed to send SMS' });
  }
});

export default router;
