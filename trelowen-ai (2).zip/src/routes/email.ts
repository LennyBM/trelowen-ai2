
import express from 'express';
import nodemailer from 'nodemailer';
import { generateChatResponse } from '../utils/openai';
import { ghlService } from '../services/ghlService';
import { leadIntelligenceService } from '../services/leadIntelligence';

const router = express.Router();

// Create email transporter
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  }
});

// Handle incoming emails
router.post('/webhook', async (req, res) => {
  try {
    const { from, subject, text, html } = req.body;
    
    // Extract email content
    const emailContent = text || html || '';
    
    // Analyze lead intelligence
    const leadData = await leadIntelligenceService.analyzeConversation(emailContent);
    
    // Update GHL contact if we have lead data
    if (leadData && from) {
      const contact = await ghlService.findContactByEmail(from);
      if (contact) {
        await ghlService.updateContact(contact.id, {
          customFields: {
            investment_budget: leadData.budgetRange,
            property_type_interest: leadData.interestType,
            customer_stage: leadData.customerStage,
            urgency_level: leadData.urgency
          }
        });
      }
    }
    
    // Generate AI response
    const systemPrompt = `You are the Trelowen AI assistant. Respond professionally to this email inquiry about real estate investment opportunities.`;
    
    const aiResponse = await generateChatResponse([
      { role: 'user', content: `Subject: ${subject}\n\n${emailContent}` }
    ], systemPrompt);
    
    // Send email response
    await transporter.sendMail({
      from: process.env.SMTP_USER,
      to: from,
      subject: `Re: ${subject}`,
      text: aiResponse
    });
    
    res.status(200).json({ success: true, message: 'Email processed successfully' });
  } catch (error) {
    console.error('Email webhook error:', error);
    res.status(500).json({ error: 'Failed to process email' });
  }
});

export default router;
