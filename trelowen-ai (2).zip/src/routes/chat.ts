
import express from 'express';
import { generateChatResponse, TRELOWEN_SYSTEM_PROMPT } from '../utils/openai';
import { ragService } from '../services/ragService';
import { leadIntelligenceService } from '../services/leadIntelligence';
import { fallbackChatbot } from '../services/fallbackChatbot';
import { logger } from '../utils/logger';

const router = express.Router();

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp?: string;
}

interface ChatRequest {
  message: string;
  conversation_id?: string;
  user_info?: {
    name?: string;
    email?: string;
    phone?: string;
    source?: string;
  };
  history?: ChatMessage[];
}

router.post('/', async (req, res) => {
  try {
    const { message, conversation_id, user_info, history = [] }: ChatRequest = req.body;

    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    // Get relevant context from knowledge base
    const contextualInfo = await ragService.getContextualResponse(message);
    
    // Analyze the conversation for lead intelligence
    const leadInsights = await leadIntelligenceService.analyzeConversation(message, history);
    
    // Build enhanced system prompt with context
    const enhancedSystemPrompt = `${TRELOWEN_SYSTEM_PROMPT}

${contextualInfo ? `RELEVANT CONTEXT:\n${contextualInfo}` : ''}

LEAD INSIGHTS:
${leadInsights.budgetRange ? `- Estimated Budget Range: ${leadInsights.budgetRange}` : ''}
${leadInsights.interestType ? `- Interest Type: ${leadInsights.interestType}` : ''}
${leadInsights.customerStage ? `- Customer Stage: ${leadInsights.customerStage}` : ''}
${leadInsights.urgency ? `- Urgency Level: ${leadInsights.urgency}` : ''}

Use this information to provide personalized, relevant responses. If the user shows strong interest, guide them toward booking a VIP viewing.`;

    // Prepare conversation history
    const messages = [
      ...history.map(msg => ({ role: msg.role, content: msg.content })),
      { role: 'user' as const, content: message }
    ];

    // Generate AI response with fallback
    let aiResponse: string;
    let usingFallback = false;
    
    try {
      aiResponse = await generateChatResponse(messages, enhancedSystemPrompt);
    } catch (error) {
      logger.warn('OpenAI unavailable, using fallback chatbot:', error);
      aiResponse = fallbackChatbot.generateResponse(message);
      usingFallback = true;
    }

    // Log conversation for analytics
    logger.info('Chat interaction', {
      conversation_id,
      user_message: message,
      ai_response: aiResponse,
      lead_insights: leadInsights,
      user_info,
      using_fallback: usingFallback
    });

    res.json({
      response: aiResponse,
      conversation_id: conversation_id || `conv_${Date.now()}`,
      lead_insights: leadInsights,
      timestamp: new Date().toISOString(),
      using_fallback: usingFallback
    });

  } catch (error) {
    logger.error('Error in chat endpoint:', error);
    res.status(500).json({ 
      error: 'Failed to generate response',
      message: 'I apologize, but I encountered an issue. Please try again or contact our sales team directly at 01288 361940.'
    });
  }
});

// Endpoint for lead qualification
router.post('/qualify-lead', async (req, res) => {
  try {
    const { conversation_history, user_info } = req.body;

    if (!conversation_history || !Array.isArray(conversation_history)) {
      return res.status(400).json({ error: 'Conversation history is required' });
    }

    const fullConversation = conversation_history.map(msg => msg.content).join('\n');
    const leadInsights = await leadIntelligenceService.analyzeConversation(fullConversation, conversation_history);

    // Generate qualification score
    const qualificationScore = leadIntelligenceService.calculateQualificationScore(leadInsights);

    res.json({
      lead_insights: leadInsights,
      qualification_score: qualificationScore,
      recommendations: leadIntelligenceService.getRecommendations(leadInsights),
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    logger.error('Error in lead qualification:', error);
    res.status(500).json({ error: 'Failed to qualify lead' });
  }
});

export default router;
