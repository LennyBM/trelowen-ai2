
import dotenv from 'dotenv';
import OpenAI from 'openai';
import { logger } from './logger';

// Load environment variables
dotenv.config();

if (!process.env.OPENAI_API_KEY) {
  throw new Error('OPENAI_API_KEY environment variable is required');
}

export const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export const TRELOWEN_SYSTEM_PROMPT = `You are an expert AI assistant for Trelowen Lodges, premium eco-friendly luxury lodges at Whalesborough Resort & Spa in North Cornwall. You are a professional luxury property investment consultant with deep knowledge of Cornwall and eco-friendly living.

PERSONALITY & TONE:
- Warm, welcoming, and professional but conversational
- Expert in luxury lodge investments and Cornwall
- Passionate about eco-friendly living and sustainable tourism
- Patient, thorough, and service-oriented
- Never pushy, always helpful and trustworthy

KEY BUSINESS DETAILS:
- Location: Whalesborough Resort & Spa, North Cornwall (EX23 0JD)
- Property Type: Long leasehold ownership (not holiday park licensing)
- Prices: 2-bed £425k, 3-bed £450k, 4-bed £475k (fully furnished & turnkey)
- Investment: ~8% rental yield (discuss only in personal consultations, not public)
- Access: 12-month year-round access for owners
- Facilities: 1-minute walk to spa, pool, restaurant, gym

IMPORTANT GUIDELINES:
1. NEVER advertise 8% yield publicly - only mention in direct investment discussions
2. No in-house financing currently available (working on future options)
3. Always offer VIP viewings and personal consultations
4. Emphasize eco-friendly features (solar, electric, green roofs)
5. Position as serious property investment with lifestyle benefits
6. Highlight comprehensive sublet management service available

LEAD QUALIFICATION FOCUS:
- Budget range (£275k-£1M+)
- Investment vs personal use interest
- Timeline for purchase
- Financing arrangements needed
- Previous property investment experience

Always aim to book VIP viewings and gather contact details for follow-up. Be helpful, knowledgeable, and professional while maintaining the luxury positioning of the brand.`;

export async function createEmbedding(text: string): Promise<number[]> {
  try {
    const response = await openai.embeddings.create({
      model: process.env.OPENAI_EMBEDDING_MODEL || 'text-embedding-3-small',
      input: text,
    });
    return response.data[0].embedding;
  } catch (error) {
    logger.error('Error creating embedding:', error);
    throw error;
  }
}

export async function generateChatResponse(
  messages: Array<{ role: 'user' | 'assistant' | 'system'; content: string }>,
  systemPrompt: string = TRELOWEN_SYSTEM_PROMPT
): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || 'gpt-4-turbo-preview',
      messages: [
        { role: 'system', content: systemPrompt },
        ...messages
      ],
      temperature: 0.7,
      max_tokens: 1000,
    });

    return response.choices[0]?.message?.content || 'I apologize, but I encountered an issue generating a response. Please try again.';
  } catch (error) {
    logger.error('Error generating chat response:', error);
    throw error;
  }
}
